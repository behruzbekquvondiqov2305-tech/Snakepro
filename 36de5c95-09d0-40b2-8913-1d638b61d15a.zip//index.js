const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const box = 20;
const size = 400 / box;

// Game data
let snake;
let food;
let dir = "RIGHT";
let score = 0;
let level = 1;
let life = 3;
let speed = 160;
let paused = false;
let game;

// Init
startGame();

// Pause button
document.getElementById("pauseBtn").addEventListener("click", () => {
  paused = !paused;
  document.getElementById("pauseBtn").innerText = paused
    ? "▶ Resume"
    : "⏸ Pause";
});

// Keyboard controls
document.addEventListener("keydown", (e) => {
  if (e.key == "ArrowUp" && dir != "DOWN") dir = "UP";
  if (e.key == "ArrowDown" && dir != "UP") dir = "DOWN";
  if (e.key == "ArrowLeft" && dir != "RIGHT") dir = "LEFT";
  if (e.key == "ArrowRight" && dir != "LEFT") dir = "RIGHT";

  if (e.key == "Enter") paused = !paused;
});

// Start or reset game
function startGame() {
  snake = [{ x: 10 * box, y: 10 * box }];
  food = randomFood();
  dir = "RIGHT";
  clearInterval(game);
  game = setInterval(draw, speed);
  updateInfo();
}

// Random food
function randomFood() {
  return {
    x: Math.floor(Math.random() * size) * box,
    y: Math.floor(Math.random() * size) * box,
  };
}

// Set direction from mobile buttons (agar qo‘shsang)
function setDir(d) {
  if (d == "UP" && dir != "DOWN") dir = "UP";
  if (d == "DOWN" && dir != "UP") dir = "DOWN";
  if (d == "LEFT" && dir != "RIGHT") dir = "LEFT";
  if (d == "RIGHT" && dir != "LEFT") dir = "RIGHT";
}

// Draw everything
function draw() {
  if (paused) {
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(0, 0, 400, 400);
    ctx.fillStyle = "white";
    ctx.font = "30px Arial";
    ctx.fillText("PAUSE", 140, 200);
    ctx.font = "16px Arial";
    ctx.fillText("Press Pause Button", 110, 230);
    return;
  }

  // Clear canvas
  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, 400, 400);

  // Draw food
  ctx.fillStyle = "red";
  ctx.beginPath();
  ctx.arc(food.x + 10, food.y + 10, 8, 0, Math.PI * 2);
  ctx.fill();

  // Draw snake
  for (let i = 0; i < snake.length; i++) {
    let grad = ctx.createLinearGradient(
      snake[i].x,
      snake[i].y,
      snake[i].x + box,
      snake[i].y + box
    );
    grad.addColorStop(0, "#00ff99");
    grad.addColorStop(1, "#00ccff");
    ctx.fillStyle = i == 0 ? "#ffff00" : grad;
    ctx.fillRect(snake[i].x, snake[i].y, box, box);
  }

  // Move snake head
  let headX = snake[0].x;
  let headY = snake[0].y;

  if (dir == "LEFT") headX -= box;
  if (dir == "RIGHT") headX += box;
  if (dir == "UP") headY -= box;
  if (dir == "DOWN") headY += box;

  // Wall teleport
  if (headX < 0) headX = 380;
  if (headX >= 400) headX = 0;
  if (headY < 0) headY = 380;
  if (headY >= 400) headY = 0;

  // Eat food
  if (headX == food.x && headY == food.y) {
    score++;
    food = randomFood();

    // Level up
    if (score % 5 == 0 && level < 5) {
      level++;
      life += 2; // har levelda jon ko‘payadi
      speed -= 20;
      clearInterval(game);
      game = setInterval(draw, speed);
    }
    updateInfo();
  } else {
    snake.pop(); // pop old tail
  }

  let newHead = { x: headX, y: headY };

  // Hit self
  if (hitSelf(newHead)) {
    life--;
    updateInfo();
    if (life <= 0) {
      clearInterval(game);
      alert("Game Over!\nScore: " + score);
      location.reload();
    } else {
      startGame();
    }
    return;
  }

  snake.unshift(newHead);
}

// Check self collision
function hitSelf(head) {
  for (let i = 0; i < snake.length; i++) {
    if (head.x == snake[i].x && head.y == snake[i].y) return true;
  }
  return false;
}

// Update panel info
function updateInfo() {
  document.getElementById("score").innerText = score;
  document.getElementById("level").innerText = level;
  document.getElementById("life").innerText = life;
}
